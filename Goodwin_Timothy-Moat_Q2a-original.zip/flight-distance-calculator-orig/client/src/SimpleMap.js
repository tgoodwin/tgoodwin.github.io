import {
  default as React,
  Component,
} from "react";

import {
  withGoogleMap,
  GoogleMap,
  Marker
} from 'react-google-maps'

const FlightMap = withGoogleMap((props) => (
  <GoogleMap
    defaultZoom={8}
    defaultCenter={props.center}
    onCenterChanged={props.onCenterChanged}
  >
    <Marker defaultPosition={props.center}></Marker>
  </GoogleMap>
));

/*
 * Add <script src="https://maps.googleapis.com/maps/api/js"></script> to your HTML to provide google.maps reference
 */
export default class SimpleMap extends Component {

  render() {
    return (
      <FlightMap
        containerElement={
          <div style={{ height: `100%` }} />
        }
        mapElement={
          <div style={{ height: `100%` }} />
        }
        center={this.props.center}
        markers={this.props.markers}
      />
    );
  }
}