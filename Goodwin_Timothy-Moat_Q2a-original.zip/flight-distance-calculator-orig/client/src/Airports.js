import React from 'react';
import Select from 'react-select';
import 'react-select/dist/react-select.min.css';

const Airports = React.createClass({
	displayName: 'Airports',
	propTypes: {
		label: React.PropTypes.string,
	},
	getInitialState () {
		return {
			backspaceRemoves: true,
			multi: true
		};
	},
	onChange (value) {
		this.setState({
			value: value,
		});
		this.props.onSelect(value);
	},
	renderOption (option) {
		if (option.code && option.name) {
			return <span>{option.name} ({option.code})</span>
		}
	},
	getUsers (input) {
		if (!input) {
			return Promise.resolve({ options: [] });
		}
		return fetch(`api/airports?q=${input}`).then(function(response) {
			return response.json();
		}).then(function(json) {
			return { options: json };
		});
	},
	render () {
		return (
			<div className="section">
				<h3 className="section-heading">{this.props.label}</h3>
				<Select.Async value={this.state.value}
				onChange={this.onChange}
				valueKey="name"
				labelKey="code"
				optionRenderer={this.renderOption}
				loadOptions={this.getUsers} />
			</div>
		);
	}
});

module.exports = Airports;