# Moat Coding Challenge: Flight Distance Calculator

This is a simple web app that allows a user to select two US airports and calculate the distance between them in nautical miles. The app runs on Node.js, using an Express server on the backend to serve a React frontend. I use webpack to bundle an optimized production build, however all client-side source files are included in `client/src`. Running the app requires the Node.js runtime, as well as node package manager for dependency installation.

##Running the Production App
The production app is an optimized build via Webpack. The production build can be served on port `3000` with `npm start`.

After unzipping the archive:

`cd flight-distance-calculator`

`npm install`

`npm start`

##The Development App
The development version of the app uses `create-react-app`, which configures a Webpack development server on `localhost:3000`. In development, I use the `node-foreman` module to forward traffic to the API server that serves airport data, running on a separate port (3001) to avoid CORS issues.
The development environment can be started as follows:

`cd flight-distance-calculator`

`npm install`

`cd client && npm install`

`cd ..`


`npm run dev`

## Design
### Backend API Server
I use a simple Express server to provide the backend that serves airport data for the app's autocomplete. The app serves location data for all US airports to the client. If the dataset were larger, I would use a variable on the query URL to serve only relevant autocomplete suggestions. However, the total size of the payload is fairly reasonable, and since the frontend autocomplete uses caching, sending all the US airport data to the client ultimately provides for a better UX without significantly impacting pageload time or browser resources.

### React.js Frontend
The frontend consists of one primary element, the `react-select` module. This component calls the API and handles most of the airport selection logic. The distance between two airports is computed using the Haversine formula.

_sidenote_

If inspecting the source files for the frontend, you may find some unused React components for rendering a flight path on Google Maps. I was building this feature out but ran into some pesky async-related issues between Google's Maps API and my React app's components, so I have submitted the app without the added feature in the interest of time.

I use airport data (`airports.json`) from the following source: https://gist.github.com/tdreyno/4278655


