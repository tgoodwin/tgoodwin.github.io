import React from 'react';
import Airports from './Airports';
import { Button, Panel } from 'react-bootstrap';

const App = React.createClass({
  getInitialState: function () {
    return {
      tripDistance: 0
    };
  },
  computeDistance: function() {
    if (!!this.state.origin && !!this.state.destination) {
      var lat1 = this.state.origin.lat;
      var lon1 = this.state.origin.lon;
      var lat2 = this.state.destination.lat;
      var lon2 = this.state.destination.lon;

      // this is my implementation of the haversine formula
      var avg_lat = parseFloat(lat1 + lat2) / 2.0;
      var avg_lon = parseFloat(lon1 + lon2) / 2.0;
      var p = 0.017453292519943295; // pi expressed in degrees
      var c = Math.cos;
      var a = 0.5 - c((lat2 - lat1) * p) / 2 +
        c(lat1 * p) * c(lat2 * p) *
        (1 - c((lon2 - lon1) * p)) / 2;
      var earth_radius = 3440; //nautical miles
      var distance_nm = Math.round((2 * earth_radius) * Math.asin(Math.sqrt(a)));
      this.setState({ tripDistance: distance_nm });
      this.state.center = { lat: avg_lat, lng: avg_lon };
    }
    else {
      this.setState({tripDistance: ''});
    }
  },
  renderDistance: function() {
    if (!!this.state.tripDistance) {
      return <span>{Math.round(this.state.tripDistance)} nautical miles</span>
    }
  },
  render: function () {
    const title= (<h3>Trip Distance (nautical miles)</h3>);
    const distance = (<span>{this.state.tripDistance} nautical miles</span>);
    return (
      <div className='App'>
      <div className='title'>Flight Distance Calculator</div>
        <div className='nav-container'>
          <div className='search-bar'><Airports label="origin" onSelect={(airport) => (
            this.setState({origin: airport})
            )}/>
          </div>
          <div className='search-bar'><Airports label="destination" onSelect={(airport) => (
            this.setState({ destination: airport })
            )}/>
          </div>
          <div className='search-button'>
            <Button bsStyle="primary" onClick={this.computeDistance}>Find Distance</Button>
          </div>
        </div>
        <div className='dist-container'>

          <div className='dist'> trip distance: {this.state.tripDistance ? this.state.tripDistance + ' acknautical miles' : ''}</div>
        </div>
      </div>
    );
  },
});

export default App;
