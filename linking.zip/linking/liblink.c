#include <stdlib.h>
#include <stdio.h>
#include "clib.h"

extern int foo (int x);

int main (int argc, char **argv) {
    int j = 2;
    int res = foo(j);
    printf("foo result: %d\n", res);
}
