#ifndef CLIB_H
#define CLIB_H

int foo (int x);

#endif
